"""
知识库文档解析和向量化服务
"""
import os
import re
import uuid
import base64
import threading
from typing import List, Dict, Any, Optional
from django.conf import settings

try:
    from backend.log_config import get_logger
    logger = get_logger(__name__)
except Exception:
    import logging
    logger = logging.getLogger(__name__)

# 使用统一的配置加载器
try:
    from backend.config_loader import config_loader
except ImportError:
    config_loader = None
    logger.warning("无法导入 config_loader，将使用环境变量")


class GLMVisionParser:
    """智谱 GLM 视觉模型文档解析器 - 用于解析文档中的图片"""

    def __init__(self):
        self.api_key = None
        self.base_url = None
        self.model = None
        self._load_config()

    def _load_config(self):
        """加载智谱 GLM 配置"""
        if config_loader:
            llm_config = config_loader.get_llm_config()
            self.api_key = llm_config.get('ZHIPU_API_KEY')
            self.base_url = llm_config.get('ZHIPU_BASE_URL', 'https://open.bigmodel.cn/api/paas/v4')
            self.model = llm_config.get('ZHIPU_VISION_MODEL', 'glm-4v-flash')

        # 备选：从环境变量读取
        if not self.api_key:
            self.api_key = os.environ.get('ZHIPU_API_KEY')
        if not self.base_url:
            self.base_url = os.environ.get('ZHIPU_BASE_URL', 'https://open.bigmodel.cn/api/paas/v4')
        if not self.model:
            self.model = os.environ.get('ZHIPU_VISION_MODEL', 'glm-4v-flash')

    def is_configured(self) -> bool:
        """检查是否已配置智谱 API"""
        return bool(self.api_key)

    def parse_image(self, image_path: str, prompt: str = None) -> str:
        """
        使用 GLM 视觉模型解析图片

        Args:
            image_path: 图片路径
            prompt: 自定义提示词

        Returns:
            图片内容描述
        """
        if not self.is_configured():
            logger.warning("智谱 GLM API 未配置，跳过图片解析")
            return ""

        try:
            import httpx

            # 读取图片并转为 base64
            with open(image_path, 'rb') as f:
                image_data = f.read()

            # 获取图片格式
            ext = os.path.splitext(image_path)[1].lower()
            mime_types = {
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.png': 'image/png',
                '.gif': 'image/gif',
                '.webp': 'image/webp',
                '.bmp': 'image/bmp'
            }
            mime_type = mime_types.get(ext, 'image/jpeg')

            # base64 编码
            image_base64 = base64.b64encode(image_data).decode('utf-8')
            image_url = f"data:{mime_type};base64,{image_base64}"

            # 默认提示词
            if not prompt:
                prompt = "请详细描述这张图片的内容，包括文字、图表、流程图等所有可见信息。如果是表格，请按表格格式输出。"

            # 调用智谱 GLM 视觉 API
            url = f"{self.base_url}/chat/completions"
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": self.model,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": prompt
                            },
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": image_url
                                }
                            }
                        ]
                    }
                ],
                "max_tokens": 2000
            }

            with httpx.Client(timeout=60) as client:
                response = client.post(url, headers=headers, json=payload)
                response.raise_for_status()
                result = response.json()

            # 打印完整的 API 响应
            logger.info(f"GLM 视觉模型 API 响应: {result}")

            content = result.get('choices', [{}])[0].get('message', {}).get('content', '')
            logger.info(f"GLM 视觉模型解析图片成功，内容长度: {len(content)} 字符")
            logger.info(f"解析内容: {content[:500]}...")  # 打印前500字符
            return content

        except Exception as e:
            logger.error(f"GLM 视觉模型解析图片失败: {e}")
            return ""

    def parse_image_from_bytes(self, image_data: bytes, mime_type: str = 'image/png', prompt: str = None) -> str:
        """
        使用 GLM 视觉模型解析图片字节数据

        Args:
            image_data: 图片字节数据
            mime_type: 图片 MIME 类型
            prompt: 自定义提示词

        Returns:
            图片内容描述
        """
        if not self.is_configured():
            logger.warning("智谱 GLM API 未配置，跳过图片解析")
            return ""

        try:
            import httpx

            # base64 编码
            image_base64 = base64.b64encode(image_data).decode('utf-8')
            image_url = f"data:{mime_type};base64,{image_base64}"

            # 默认提示词
            if not prompt:
                prompt = "请详细描述这张图片的内容，包括文字、图表、流程图等所有可见信息。如果是表格，请按表格格式输出。"

            # 调用智谱 GLM 视觉 API
            url = f"{self.base_url}/chat/completions"
            headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            }
            payload = {
                "model": self.model,
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": prompt
                            },
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": image_url
                                }
                            }
                        ]
                    }
                ],
                "max_tokens": 2000
            }

            with httpx.Client(timeout=60) as client:
                response = client.post(url, headers=headers, json=payload)
                response.raise_for_status()
                result = response.json()

            content = result.get('choices', [{}])[0].get('message', {}).get('content', '')
            return content

        except Exception as e:
            logger.error(f"GLM 视觉模型解析图片失败: {e}")
            return ""


# 全局 GLM 视觉解析器实例
glm_vision_parser = GLMVisionParser()


class DocumentParser:
    """文档解析器 - 支持PDF、Word、TXT、MD格式"""

    @staticmethod
    def extract_text_from_pdf(file_path: str, use_vision: bool = True) -> str:
        """
        从PDF文件提取文本和图片（使用 GLM 视觉模型解析图片)

        Args:
            file_path: PDF文件路径
            use_vision: 是否使用 GLM 视觉模型解析图片
        """
        text_content = []
        images_text = []

        try:
            import fitz  # PyMuPDF
            doc = fitz.open(file_path)

            for page_num in range(len(doc)):
                page = doc[page_num]

                # 提取文本
                page_text = page.get_text()
                if page_text:
                    text_content.append(page_text)
                    text_content.append("\n")

                # 提取图片并使用 GLM 视觉模型解析
                if use_vision and glm_vision_parser.is_configured():
                    images = page.get_images(full=True)
                    for img_index in range(len(images)):
                        xref = images[img_index]
                        try:
                            base_image = doc.extract_image(xref)
                            if base_image:
                                # 保存临时图片
                                temp_dir = os.path.join(settings.BASE_DIR, 'expand', 'temp_images')
                                os.makedirs(temp_dir, exist_ok=True)
                                ext = base_image.get("ext", "png")
                                temp_image_path = os.path.join(temp_dir, f"page_{page_num}_img_{img_index}.{ext}")
                                with open(temp_image_path, 'wb') as f:
                                    f.write(base_image["image"])

                                # 使用 GLM 视觉模型解析图片
                                image_text = glm_vision_parser.parse_image(temp_image_path)
                                if image_text:
                                    images_text.append(f"\n[图片{page_num + 1}-{img_index + 1}]: {image_text}")
                                    logger.info(f"PDF 第 {page_num + 1} 页，第 {img_index + 1} 张图片解析完成")

                                # 删除临时图片
                                try:
                                    os.remove(temp_image_path)
                                except:
                                    pass
                        except Exception as img_error:
                            logger.error(f"PDF 第 {page_num + 1} 页图片 {img_index + 1} 提取/解析失败: {img_error}")

                else:
                    logger.info("GLM 视觉模型未配置，跳过图片解析")

            doc.close()

            # 合并文本和图片描述
            full_text = "".join(text_content)
            if images_text:
                full_text += "\n\n[图片内容]:\n" + "\n".join(images_text)

            return full_text.strip()
        except ImportError:
            logger.warning("PyMuPDF未安装，尝试使用pdfplumber")
            try:
                import pdfplumber
                text = ""
                with pdfplumber.open(file_path) as pdf:
                    for page in pdf.pages:
                        page_text = page.extract_text()
                        if page_text:
                            text += page_text + "\n"
                return text.strip()
            except ImportError:
                logger.error("pdfplumber也未安装，无法解析PDF")
                return ""
        except Exception as e:
            logger.error(f"PDF解析失败: {e}")
            return ""

    @staticmethod
    def extract_text_from_docx(file_path: str, use_vision: bool = True) -> str:
        """从Word文件提取文本和图片（使用 GLM 视觉模型解析图片)"""
        try:
            from docx import Document
            doc = Document(file_path)
            text = []
            images_text = []

            # 提取段落文本
            for para in doc.paragraphs:
                if para.text.strip():
                    text.append(para.text)

            # 提取表格内容
            for table in doc.tables:
                for row in table.rows:
                    row_text = []
                    for cell in row.cells:
                        if cell.text.strip():
                            row_text.append(cell.text.strip())
                    if row_text:
                        text.append(" | ".join(row_text))

            # 提取图片并使用 GLM 视觉模型解析
            if use_vision and glm_vision_parser.is_configured():
                for rel in doc.part.rels.values():
                    if "image" in rel.reltype:
                        try:
                            image = rel.image
                            # 保存临时图片
                            temp_dir = os.path.join(settings.BASE_DIR, 'expand', 'temp_images')
                            os.makedirs(temp_dir, exist_ok=True)
                            ext = image.ext if hasattr(image, 'ext') else 'png'
                            temp_image_path = os.path.join(temp_dir, f"docx_img_{len(images_text)}.{ext}")
                            with open(temp_image_path, 'wb') as f:
                                f.write(image.blob)

                            # 使用 GLM 视觉模型解析图片
                            image_text = glm_vision_parser.parse_image(temp_image_path)
                            if image_text:
                                images_text.append(f"\n[图片{len(images_text) + 1}]: {image_text}")
                                logger.info(f"Word 文档第 {len(images_text)} 张图片解析完成")

                            # 删除临时图片
                            try:
                                os.remove(temp_image_path)
                            except:
                                pass
                        except Exception as img_error:
                            logger.error(f"Word 文档图片提取/解析失败: {img_error}")

            # 合并文本和图片描述
            full_text = "\n".join(text)
            if images_text:
                full_text += "\n\n[图片内容]:\n" + "\n".join(images_text)

            return full_text.strip()
        except ImportError:
            logger.error("python-docx未安装，无法解析Word文档")
            return ""
        except Exception as e:
            logger.error(f"Word解析失败: {e}")
            return ""

    @staticmethod
    def extract_text_from_txt(file_path: str) -> str:
        """从TXT文件提取文本"""
        try:
            # 尝试多种编码
            encodings = ['utf-8', 'gbk', 'gb2312', 'utf-16']
            for encoding in encodings:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        return f.read().strip()
                except UnicodeDecodeError:
                    continue
            return ""
        except Exception as e:
            logger.error(f"TXT解析失败: {e}")
            return ""

    @staticmethod
    def extract_text_from_md(file_path: str) -> str:
        """从Markdown文件提取文本"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            # 简单的Markdown清理，保留文本内容
            # 移除代码块标记但保留内容
            content = re.sub(r'```[\w]*\n?', '', content)
            content = re.sub(r'`([^`]+)`', r'\1', content)
            # 移除链接但保留文本
            content = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', content)
            # 移除图片
            content = re.sub(r'!\[([^\]]*)\]\([^)]+\)', '', content)
            # 移除标题标记
            content = re.sub(r'^#{1,6}\s+', '', content, flags=re.MULTILINE)
            # 移除粗体/斜体标记
            content = re.sub(r'\*\*([^*]+)\*\*', r'\1', content)
            content = re.sub(r'\*([^*]+)\*', r'\1', content)
            content = re.sub(r'__([^_]+)__', r'\1', content)
            content = re.sub(r'_([^_]+)_', r'\1', content)
            return content.strip()
        except Exception as e:
            logger.error(f"Markdown解析失败: {e}")
            return ""

    @classmethod
    def extract_text(cls, file_path: str, document_type: str, use_vision: bool = True) -> str:
        """根据文档类型提取文本"""
        if not os.path.exists(file_path):
            logger.error(f"文件不存在: {file_path}")
            return ""

        if document_type == 'pdf':
            # PDF 需要传递 use_vision 参数
            return cls.extract_text_from_pdf(file_path, use_vision=use_vision)
        elif document_type in ['docx', 'doc']:
            return cls.extract_text_from_docx(file_path)
        elif document_type == 'txt':
            return cls.extract_text_from_txt(file_path)
        elif document_type == 'md':
            return cls.extract_text_from_md(file_path)
        else:
            logger.error(f"不支持的文档类型: {document_type}")
            return ""


class TextChunker:
    """文本分块器"""

    @staticmethod
    def split_text(
        text: str,
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        separators: List[str] = None
    ) -> List[Dict[str, Any]]:
        """
        将文本分割成多个块

        Args:
            text: 要分割的文本
            chunk_size: 每个块的最大字符数
            chunk_overlap: 相邻块之间的重叠字符数
            separators: 分隔符优先级列表

        Returns:
            分块列表，每个块包含 text, start_index, end_index
        """
        if not text or not text.strip():
            return []

        if separators is None:
            # 中文优先按段落、句号分割
            separators = ["\n\n", "\n", "。", "！", "？", "；", ".", "!", "?", ";", " ", ""]

        chunks = []
        start = 0
        text_length = len(text)

        while start < text_length:
            # 确定当前块的结束位置
            end = start + chunk_size

            if end >= text_length:
                # 最后一块
                chunk_text = text[start:].strip()
                if chunk_text:
                    chunks.append({
                        'text': chunk_text,
                        'start_index': start,
                        'end_index': text_length
                    })
                break

            # 尝试在chunk_size附近找到最佳分隔点
            best_end = end
            for separator in separators:
                # 在 end 附近向后查找分隔符
                idx = text.find(separator, end - chunk_overlap, end + chunk_overlap)
                if idx != -1:
                    best_end = idx + len(separator)
                    break

            # 如果找不到合适的分隔点，强制在 chunk_size 处分割
            if best_end > end + chunk_overlap:
                best_end = end

            chunk_text = text[start:best_end].strip()
            if chunk_text:
                chunks.append({
                    'text': chunk_text,
                    'start_index': start,
                    'end_index': best_end
                })

            # 下一块的起始位置（考虑重叠）
            start = best_end - chunk_overlap
            if start < 0:
                start = 0
            # 避免无限循环
            if start <= chunks[-1]['start_index']:
                start = best_end

        return chunks


class VectorStoreService:
    """向量存储服务 - 使用 ChromaDB"""

    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return

        self._initialized = True
        self.chroma_client = None
        self.embedding_function = None
        self._init_chroma()
        self._init_embedding()

    def _init_chroma(self):
        """初始化 ChromaDB 客户端"""
        try:
            import chromadb
            from chromadb.config import Settings

            # ChromaDB 数据存储路径
            chroma_path = os.path.join(settings.BASE_DIR, 'expand', 'chroma_db')
            os.makedirs(chroma_path, exist_ok=True)

            self.chroma_client = chromadb.PersistentClient(
                path=chroma_path,
                settings=Settings(
                    anonymized_telemetry=False,
                    allow_reset=True
                )
            )
            logger.info(f"ChromaDB 初始化成功，存储路径: {chroma_path}")
        except ImportError:
            logger.error("chromadb 未安装，请运行: pip install chromadb")
            self.chroma_client = None
        except Exception as e:
            logger.error(f"ChromaDB 初始化失败: {e}")
            self.chroma_client = None

    def _init_embedding(self):
        """初始化嵌入模型"""
        try:
            from chromadb.utils import embedding_functions

            # 从 config.yaml 读取 LLM 配置
            api_key = None
            base_url = None
            embedding_model = None

            if config_loader:
                llm_config = config_loader.get_llm_config()
                api_key = llm_config.get('QWEN_API_KEY') or llm_config.get('DASHSCOPE_API_KEY')
                base_url = llm_config.get('QWEN_BASE_URL') or llm_config.get('DASHSCOPE_BASE_URL')
                embedding_model = llm_config.get('EMBEDDING_MODEL')

            # 备选：从 settings 或环境变量读取
            if not api_key:
                api_key = getattr(settings, 'QWEN_API_KEY', None) or \
                          getattr(settings, 'DASHSCOPE_API_KEY', None) or \
                          os.environ.get('QWEN_API_KEY') or \
                          os.environ.get('DASHSCOPE_API_KEY')

            if not base_url:
                base_url = getattr(settings, 'QWEN_BASE_URL', None) or \
                           os.environ.get('QWEN_BASE_URL')

            # 检查必要配置
            if not api_key:
                error_msg = "未配置 Embedding API Key，请在 config.yaml 中配置 LLM.QWEN_API_KEY"
                logger.error(error_msg)
                raise ValueError(error_msg)

            if not embedding_model:
                embedding_model = "text-embedding-v3"
                logger.warning(f"未配置 EMBEDDING_MODEL，使用默认模型: {embedding_model}")

            # 使用 OpenAI 兼容的 embedding 函数
            self.embedding_function = embedding_functions.OpenAIEmbeddingFunction(
                api_key=api_key,
                model_name=embedding_model,
                api_base=base_url or "https://dashscope.aliyuncs.com/compatible-mode/v1"
            )
            logger.info(f"Embedding 模型初始化成功: {embedding_model}")

        except ImportError as e:
            logger.error(f"嵌入函数初始化失败: {e}")
            self.embedding_function = None
        except ValueError:
            raise
        except Exception as e:
            logger.error(f"嵌入模型初始化失败: {e}")
            self.embedding_function = None

    def get_or_create_collection(self, collection_name: str):
        """获取或创建向量集合"""
        if not self.chroma_client:
            logger.error("ChromaDB 客户端未初始化")
            return None

        try:
            collection = self.chroma_client.get_or_create_collection(
                name=collection_name,
                embedding_function=self.embedding_function,
                metadata={"hnsw:space": "cosine"}
            )
            return collection
        except Exception as e:
            logger.error(f"创建/获取集合失败: {e}")
            return None

    def delete_collection(self, collection_name: str) -> bool:
        """删除向量集合"""
        if not self.chroma_client:
            return False

        try:
            self.chroma_client.delete_collection(collection_name)
            logger.info(f"集合 {collection_name} 已删除")
            return True
        except Exception as e:
            logger.error(f"删除集合失败: {e}")
            return False

    def add_documents(
        self,
        collection_name: str,
        documents: List[str],
        metadatas: List[Dict] = None,
        ids: List[str] = None,
        batch_size: int = 10
    ) -> bool:
        """
        向集合添加文档（分批处理，每批最多 batch_size 个）

        Args:
            collection_name: 集合名称
            documents: 文档文本列表
            metadatas: 元数据列表
            ids: 文档ID列表
            batch_size: 每批处理的最大文档数（阿里云 API 限制为 10）

        Returns:
            是否成功
        """
        collection = self.get_or_create_collection(collection_name)
        if not collection:
            return False

        try:
            if ids is None:
                ids = [str(uuid.uuid4()) for _ in documents]

            total_docs = len(documents)
            success_count = 0

            # 分批处理，每批最多 batch_size 个文档
            for i in range(0, total_docs, batch_size):
                batch_end = min(i + batch_size, total_docs)
                batch_docs = documents[i:batch_end]
                batch_ids = ids[i:batch_end]
                batch_metadatas = metadatas[i:batch_end] if metadatas else None

                try:
                    collection.add(
                        documents=batch_docs,
                        metadatas=batch_metadatas,
                        ids=batch_ids
                    )
                    success_count += len(batch_docs)
                    logger.info(f"批次 {i // batch_size + 1}: 成功添加 {len(batch_docs)} 个文档")
                except Exception as batch_error:
                    logger.error(f"批次 {i // batch_size + 1} 添加失败: {batch_error}")
                    # 继续处理下一批，不中断整个流程

            if success_count == total_docs:
                logger.info(f"成功添加 {success_count} 个文档到集合 {collection_name}")
                return True
            elif success_count > 0:
                logger.warning(f"部分成功: {success_count}/{total_docs} 个文档添加到集合 {collection_name}")
                return True
            else:
                return False

        except Exception as e:
            logger.error(f"添加文档失败: {e}")
            return False

    def query(
        self,
        collection_name: str,
        query_texts: List[str],
        n_results: int = 5,
        where: Dict = None
    ) -> Dict:
        """
        查询相似文档

        Args:
            collection_name: 集合名称
            query_texts: 查询文本列表
            n_results: 返回结果数量
            where: 元数据过滤条件

        Returns:
            查询结果
        """
        collection = self.get_or_create_collection(collection_name)
        if not collection:
            return {'ids': [], 'documents': [], 'metadatas': [], 'distances': []}

        try:
            results = collection.query(
                query_texts=query_texts,
                n_results=n_results,
                where=where
            )
            return results
        except Exception as e:
            logger.error(f"查询失败: {e}")
            return {'ids': [], 'documents': [], 'metadatas': [], 'distances': []}

    def delete_documents(self, collection_name: str, ids: List[str]) -> bool:
        """删除指定文档"""
        collection = self.get_or_create_collection(collection_name)
        if not collection:
            return False

        try:
            collection.delete(ids=ids)
            logger.info(f"成功从集合 {collection_name} 删除 {len(ids)} 个文档")
            return True
        except Exception as e:
            logger.error(f"删除文档失败: {e}")
            return False

    def get_collection_count(self, collection_name: str) -> int:
        """获取集合中的文档数量"""
        collection = self.get_or_create_collection(collection_name)
        if not collection:
            return 0

        try:
            return collection.count()
        except Exception as e:
            logger.error(f"获取集合数量失败: {e}")
            return 0


class KnowledgeBaseService:
    """知识库服务 - 整合文档解析、分块和向量化"""

    def __init__(self):
        self.parser = DocumentParser()
        self.chunker = TextChunker()
        self.vector_store = VectorStoreService()

    def process_document(
        self,
        document,
        chunk_size: int = 500,
        chunk_overlap: int = 50,
        enable_vectorization: bool = True,
        use_vision: bool = True
    ) -> Dict[str, Any]:
        """
        处理单个文档：解析文本、分块、向量化

        Args:
            document: KnowledgeDocument 实例
            chunk_size: 分块大小
            chunk_overlap: 分块重叠
            enable_vectorization: 是否进行向量化
            use_vision: 是否使用 GLM 视觉模型解析图片

        Returns:
            处理结果
        """
        result = {
            'success': False,
            'text_length': 0,
            'chunk_count': 0,
            'vectorized': False,
            'error': None
        }

        try:
            # 1. 提取文本（使用 GLM 视觉模型解析图片）
            if document.file and os.path.exists(document.file.path):
                text = self.parser.extract_text(
                    document.file.path,
                    document.document_type,
                    use_vision=use_vision
                )
            else:
                text = document.content or ""

            result['text_length'] = len(text)

            # 保存提取的文本
            if text:
                from .models import KnowledgeDocument
                KnowledgeDocument.objects.filter(pk=document.pk).update(content=text)

            # 2. 分块
            chunks = self.chunker.split_text(
                text,
                chunk_size=chunk_size,
                chunk_overlap=chunk_overlap
            )
            result['chunk_count'] = len(chunks)

            # 更新分块数量
            from .models import KnowledgeDocument
            KnowledgeDocument.objects.filter(pk=document.pk).update(
                chunk_count=len(chunks),
                vector_status='processing'
            )

            # 3. 向量化
            if enable_vectorization and chunks:
                collection_name = document.knowledge_base.collection_name
                if collection_name:
                    documents = [chunk['text'] for chunk in chunks]
                    metadatas = [{
                        'document_id': document.id,
                        'knowledge_base_id': document.knowledge_base_id,
                        'start_index': chunk['start_index'],
                        'end_index': chunk['end_index'],
                        'title': document.title,
                    } for chunk in chunks]
                    ids = [f"{document.id}_{i}" for i in range(len(chunks))]

                    success = self.vector_store.add_documents(
                        collection_name=collection_name,
                        documents=documents,
                        metadatas=metadatas,
                        ids=ids
                    )

                    if success:
                        KnowledgeDocument.objects.filter(pk=document.pk).update(
                            vector_status='completed'
                        )
                        result['vectorized'] = True
                    else:
                        KnowledgeDocument.objects.filter(pk=document.pk).update(
                            vector_status='failed',
                            vector_error='向量化存储失败'
                        )
                        result['error'] = '向量化存储失败'
                else:
                    result['error'] = '知识库未配置向量集合'
            else:
                KnowledgeDocument.objects.filter(pk=document.pk).update(
                    vector_status='completed' if not enable_vectorization else 'failed'
                )
                result['vectorized'] = not enable_vectorization

            result['success'] = True

        except Exception as e:
            logger.error(f"文档处理失败: {e}")
            result['error'] = str(e)
            from .models import KnowledgeDocument
            KnowledgeDocument.objects.filter(pk=document.pk).update(
                vector_status='failed',
                vector_error=str(e)
            )

        return result

    def create_knowledge_base_collection(self, knowledge_base) -> str:
        """
        为知识库创建向量集合

        Args:
            knowledge_base: KnowledgeBase 实例

        Returns:
            集合名称
        """
        collection_name = f"kb_{knowledge_base.id}_{uuid.uuid4().hex[:8]}"

        collection = self.vector_store.get_or_create_collection(collection_name)
        if collection:
            # 保存集合名称到知识库
            from .models import KnowledgeBase
            KnowledgeBase.objects.filter(pk=knowledge_base.pk).update(
                collection_name=collection_name
            )
            return collection_name
        return ""

    def search_similar(
        self,
        knowledge_base,
        query: str,
        n_results: int = 5
    ) -> List[Dict]:
        """
        在知识库中搜索相似内容

        Args:
            knowledge_base: KnowledgeBase 实例
            query: 查询文本
            n_results: 返回结果数量

        Returns:
            相似文档列表
        """
        if not knowledge_base.collection_name:
            return []

        results = self.vector_store.query(
            collection_name=knowledge_base.collection_name,
            query_texts=[query],
            n_results=n_results
        )

        # 格式化结果
        formatted_results = []
        if results and results.get('ids'):
            for i, doc_id in enumerate(results['ids'][0]):
                formatted_results.append({
                    'id': doc_id,
                    'text': results['documents'][0][i] if results.get('documents') else '',
                    'metadata': results['metadatas'][0][i] if results.get('metadatas') else {},
                    'distance': results['distances'][0][i] if results.get('distances') else 0
                })

        return formatted_results

    def delete_knowledge_base_vectors(self, knowledge_base) -> bool:
        """删除知识库的所有向量数据"""
        if knowledge_base.collection_name:
            return self.vector_store.delete_collection(knowledge_base.collection_name)
        return True


# 单例服务实例
knowledge_base_service = KnowledgeBaseService()
